package com.smartvoiceai.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smartvoiceai.app.network.NetworkClient
import com.smartvoiceai.app.voice.VoiceInteractionManager

@Composable
fun SettingsScreen(voiceManager: VoiceInteractionManager) {
    val activeLang by voiceManager.activeLanguage.collectAsState()
    val speed by voiceManager.speechSpeed.collectAsState()
    var backendUrl by remember { mutableStateOf(NetworkClient.getBaseUrl()) }
    var selectedModel by remember { mutableStateOf("gemini-3.8-flash") }
    var saveSuccess by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("Assistant Settings", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Customize voice engine, models, and isolated backend", color = Color(0xFF94A3B8), fontSize = 12.sp)

        Spacer(modifier = Modifier.height(16.dp))

        // Language & Speech Section
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("VOICE & LANGUAGE", color = Color(0xFF38BDF8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Primary Language", color = Color.White, fontSize = 14.sp)
                    Row {
                        FilterChip(
                            selected = activeLang == "bn-BD",
                            onClick = { voiceManager.toggleLanguage("bn-BD") },
                            label = { Text("বাংলা") }
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        FilterChip(
                            selected = activeLang == "en-US",
                            onClick = { voiceManager.toggleLanguage("en-US") },
                            label = { Text("English") }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text("Speech Playback Speed: ${(speed * 10).toInt() / 10f}x", color = Color.White, fontSize = 14.sp)
                Slider(
                    value = speed,
                    onValueChange = { voiceManager.speechSpeed.value = it },
                    valueRange = 0.7f..1.5f,
                    steps = 7,
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFF3B82F6),
                        activeTrackColor = Color(0xFF3B82F6)
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Backend Connection & Model Section
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("BACKEND & AI MODEL", color = Color(0xFF38BDF8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(10.dp))

                Text("Active Reasoning Model", color = Color(0xFF94A3B8), fontSize = 12.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = selectedModel == "gemini-3.8-flash",
                        onClick = { selectedModel = "gemini-3.8-flash" },
                        label = { Text("gemini-3.8-flash") }
                    )
                    FilterChip(
                        selected = selectedModel == "gemini-4-argon",
                        onClick = { selectedModel = "gemini-4-argon" },
                        label = { Text("gemini-4-argon") }
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text("Backend Host Endpoint", color = Color(0xFF94A3B8), fontSize = 12.sp)
                Spacer(modifier = Modifier.height(4.dp))
                TextField(
                    value = backendUrl,
                    onValueChange = { backendUrl = it },
                    modifier = Modifier.fillMaxWidth(),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFF0F172A),
                        unfocusedContainerColor = Color(0xFF0F172A),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(8.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = {
                        NetworkClient.setBaseUrl(backendUrl)
                        saveSuccess = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Save & Reconnect")
                }

                if (saveSuccess) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Endpoint saved successfully!", color = Color(0xFF10B981), fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Security & Isolation Policy
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Security & Sandbox Isolation", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "• Server-Side Gemini API (No keys leaked in APK)\n• Strict Timeout & Memory Quota on Code Execution\n• Path Traversal & Injection Prevention\n• Safe Plan-Execute-Verify Gate",
                    color = Color(0xFF94A3B8),
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }
        }
    }
}
