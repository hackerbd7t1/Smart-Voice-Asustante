package com.smartvoiceai.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smartvoiceai.app.network.NetworkClient
import kotlinx.coroutines.launch

@Composable
fun TestLogsScreen() {
    val coroutineScope = rememberCoroutineScope()
    var isRunning by remember { mutableStateOf(false) }
    var executionTime by remember { mutableStateOf(18L) }
    var exitCode by remember { mutableStateOf(0) }
    var logsText by remember {
        mutableStateOf(
            """[PHP Sandbox Engine] Initializing isolated micro-sandbox...
[PHP Sandbox Engine] Target: test_auth.php
[PHP Environment] PHP 8.3 CLI Mode • Strict Types: Enabled
[SUITE] Initializing automated assertions...
[PASS] Test 1: Bcrypt Hashing cost factor 12 verified.
[PASS] Test 2: Cryptographic CSPRNG entropy verified (64 chars).
[PASS] Test 3: SQL Injection mitigation with PDO Prepared Statements verified.

==> Verification summary: 3 tests executed, 3 passed, 0 failed.
==> Exit Code: 0 (ALL ASSERTIONS VERIFIED)"""
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp)
    ) {
        // Log Header Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Isolated Sandbox Runner",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Text(
                    text = "Security-sandboxed test execution engine",
                    color = Color(0xFF94A3B8),
                    fontSize = 11.sp
                )
            }

            Button(
                onClick = {
                    coroutineScope.launch {
                        isRunning = true
                        try {
                            val res = NetworkClient.apiService.executeSandbox(
                                "proj-php-auth",
                                mapOf("targetFile" to "test_auth.php")
                            )
                            if (res.isSuccessful && res.body() != null) {
                                val b = res.body()!!
                                logsText = b.output
                                executionTime = b.executionTimeMs
                                exitCode = b.exitCode
                            }
                        } catch (e: Exception) {
                            logsText += "\nExecution failed: ${e.message}"
                        } finally {
                            isRunning = false
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(if (isRunning) "Running..." else "Re-run Tests", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Metrics Banner
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("STATUS", color = Color(0xFF94A3B8), fontSize = 10.sp)
                    Text("VERIFIED PASS", color = Color(0xFF10B981), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("EXIT CODE", color = Color(0xFF94A3B8), fontSize = 10.sp)
                    Text("$exitCode (OK)", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("TIME", color = Color(0xFF94A3B8), fontSize = 10.sp)
                    Text("${executionTime}ms", color = Color(0xFF38BDF8), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Terminal Output Screen
        Card(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF030712)),
            shape = RoundedCornerShape(8.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF111827))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("SANDBOX OUTPUT CONSOLE", color = Color(0xFF9CA3AF), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Icon(Icons.Default.Shield, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(14.dp))
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(12.dp)
                        .verticalScroll(rememberScrollState())
                        .horizontalScroll(rememberScrollState())
                ) {
                    Text(
                        text = logsText,
                        color = Color(0xFF4ADE80),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}
