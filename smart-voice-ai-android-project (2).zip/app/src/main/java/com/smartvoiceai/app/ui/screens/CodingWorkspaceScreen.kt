package com.smartvoiceai.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smartvoiceai.app.data.ProjectDetails
import com.smartvoiceai.app.data.ProjectFileItem
import com.smartvoiceai.app.network.NetworkClient
import kotlinx.coroutines.launch

@Composable
fun CodingWorkspaceScreen() {
    val coroutineScope = rememberCoroutineScope()
    var projectDetails by remember { mutableStateOf<ProjectDetails?>(null) }
    var selectedFile by remember { mutableStateOf<ProjectFileItem?>(null) }
    var isSaving by remember { mutableStateOf(false) }
    var saveStatus by remember { mutableStateOf<String?>(null) }

    fun loadProject() {
        coroutineScope.launch {
            try {
                val res = NetworkClient.apiService.getProjectDetails("proj-php-auth")
                if (res.isSuccessful && res.body() != null) {
                    projectDetails = res.body()
                    if (selectedFile == null && projectDetails!!.files.isNotEmpty()) {
                        selectedFile = projectDetails!!.files[0]
                    }
                }
            } catch (e: Exception) {
                saveStatus = "Failed to load project: ${e.message}"
            }
        }
    }

    LaunchedEffect(Unit) {
        loadProject()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        // Workspace Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = projectDetails?.name ?: "PHP Secure Authentication",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Text(
                    text = "Sandbox Isolated Workspace • PHP 8.2 & PDO",
                    color = Color(0xFF94A3B8),
                    fontSize = 11.sp
                )
            }

            IconButton(onClick = { loadProject() }) {
                Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = Color(0xFF60A5FA))
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // File Tabs
        if (projectDetails != null) {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(projectDetails!!.files) { file ->
                    val isSelected = selectedFile?.path == file.path
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedFile = file },
                        label = { Text(file.name, fontSize = 12.sp) },
                        leadingIcon = {
                            Icon(
                                imageVector = when (file.language) {
                                    "php" -> Icons.Default.DataObject
                                    "sql" -> Icons.Default.Storage
                                    "css" -> Icons.Default.Brush
                                    else -> Icons.Default.InsertDriveFile
                                },
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF2563EB),
                            selectedLabelColor = Color.White,
                            containerColor = Color(0xFF1E293B),
                            labelColor = Color(0xFF94A3B8)
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Code Editor Box with Monospace font and Line Numbers
        Card(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            shape = RoundedCornerShape(8.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Editor File Path Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1E293B))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = selectedFile?.path ?: "No file selected",
                        color = Color(0xFF38BDF8),
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "${selectedFile?.language?.uppercase() ?: "TEXT"}",
                        color = Color(0xFF94A3B8),
                        fontSize = 10.sp
                    )
                }

                // Code Content
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(8.dp)
                        .verticalScroll(rememberScrollState())
                        .horizontalScroll(rememberScrollState())
                ) {
                    Text(
                        text = selectedFile?.content ?: "// Select a file from the tabs above",
                        color = Color(0xFFE2E8F0),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Action Toolbar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Button(
                onClick = {
                    coroutineScope.launch {
                        isSaving = true
                        try {
                            if (selectedFile != null) {
                                NetworkClient.apiService.saveFile(
                                    "proj-php-auth",
                                    mapOf(
                                        "path" to selectedFile!!.path,
                                        "content" to selectedFile!!.content,
                                        "language" to selectedFile!!.language
                                    )
                                )
                                saveStatus = "File saved safely to isolated sandbox."
                            }
                        } catch (e: Exception) {
                            saveStatus = "Save failed: ${e.message}"
                        } finally {
                            isSaving = false
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Save File")
            }

            Button(
                onClick = {
                    coroutineScope.launch {
                        try {
                            saveStatus = "Running tests in isolated sandbox..."
                            val res = NetworkClient.apiService.executeSandbox(
                                "proj-php-auth",
                                mapOf("targetFile" to (selectedFile?.path ?: "test_auth.php"))
                            )
                            if (res.isSuccessful && res.body() != null) {
                                val b = res.body()!!
                                saveStatus = "Test passed! Verified: ${b.verified} (${b.executionTimeMs}ms)"
                            }
                        } catch (e: Exception) {
                            saveStatus = "Test run error: ${e.message}"
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Execute Tests")
            }
        }

        if (saveStatus != null) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = saveStatus!!,
                color = if (saveStatus!!.contains("error", true) || saveStatus!!.contains("fail", true)) Color(0xFFEF4444) else Color(0xFF10B981),
                fontSize = 11.sp
            )
        }
    }
}
