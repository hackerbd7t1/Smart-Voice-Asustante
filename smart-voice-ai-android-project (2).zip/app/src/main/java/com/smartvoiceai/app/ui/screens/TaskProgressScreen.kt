package com.smartvoiceai.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smartvoiceai.app.data.TaskStep

@Composable
fun TaskProgressScreen() {
    // Demo verified task steps mirroring our backend Plan-Execute-Verify model
    val steps = remember {
        listOf(
            TaskStep(
                id = "step-1",
                title = "১. ডেটাবেস স্কিমা ডিজাইন ও অডিট টেবিল",
                description = "Created users & audit logs schema with Bcrypt hash column in schema.sql",
                status = "completed",
                tool = "sql_generator"
            ),
            TaskStep(
                id = "step-2",
                title = "২. PDO সিকিউর কানেকশন ও এরর হ্যান্ডলিং",
                description = "Configured PDO with PDO::ERRMODE_EXCEPTION and disabled emulation in db.php",
                status = "completed",
                tool = "php_scaffolder"
            ),
            TaskStep(
                id = "step-3",
                title = "৩. পাসওয়ার্ড হ্যাশিং ও CSRF গার্ড সার্ভিস",
                description = "Implemented AuthService with password_hash(PASSWORD_BCRYPT) and CSPRNG tokens",
                status = "completed",
                tool = "auth_builder"
            ),
            TaskStep(
                id = "step-4",
                title = "৪. আইসোলেটেড স্যান্ডবক্সে টেস্ট রান ও ভেরিফিকেশন",
                description = "Executed test_auth.php in sandbox container: 3/3 tests passed with exit code 0",
                status = "completed",
                tool = "sandbox_test_runner"
            )
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp)
    ) {
        // Plan Header Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("ACTIVE AGENT PLAN", color = Color(0xFF38BDF8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Surface(
                        color = Color(0xFF065F46),
                        shape = RoundedCornerShape(9999.dp)
                    ) {
                        Text(
                            text = "VERIFIED • EXIT CODE 0",
                            color = Color(0xFF34D399),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "PHP Secure Authentication System & Automated Verification",
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "বাংলা বিবরণ: পাসওয়ার্ড হ্যাশিং, CSRF টোকেন ভ্যালিডেশন এবং SQL ইনজেকশন প্রোটেকশন স্যান্ডবক্স টেস্টে শতভাগ সফলভাবে পাস করেছে।",
                    color = Color(0xFFCBD5E1),
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Plan-Execute-Verify Lifecycle Steps",
            color = Color(0xFF94A3B8),
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
        )
        Spacer(modifier = Modifier.height(10.dp))

        // Step by Step List
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(steps) { step ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .background(Color(0xFF10B981), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = step.title,
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = step.description,
                                color = Color(0xFF94A3B8),
                                fontSize = 12.sp,
                                lineHeight = 16.sp
                            )
                            if (step.tool != null) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Tool: ${step.tool}",
                                    color = Color(0xFF60A5FA),
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
