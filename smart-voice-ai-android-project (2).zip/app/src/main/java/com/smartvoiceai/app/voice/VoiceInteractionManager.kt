package com.smartvoiceai.app.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.*

class VoiceInteractionManager(private val context: Context) : RecognitionListener {

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null

    val isListening = MutableStateFlow(false)
    val isSpeaking = MutableStateFlow(false)
    val currentRmsDb = MutableStateFlow(0f)
    val recognizedText = MutableStateFlow("")
    val activeLanguage = MutableStateFlow("bn-BD") // "bn-BD" or "en-US"
    val speechSpeed = MutableStateFlow(1.0f)
    val isHandsfreeMode = MutableStateFlow(false)

    var onSpeechFinalResult: ((String) -> Unit)? = null

    init {
        initSpeechRecognizer()
        initTextToSpeech()
    }

    private fun initSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(this@VoiceInteractionManager)
            }
        }
    }

    private fun initTextToSpeech() {
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val locale = if (activeLanguage.value.startsWith("bn")) Locale("bn", "BD") else Locale.US
                val result = textToSpeech?.setLanguage(locale)
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    textToSpeech?.language = Locale.US
                }
                textToSpeech?.setSpeechRate(speechSpeed.value)
            }
        }

        textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                isSpeaking.value = true
            }

            override fun onDone(utteranceId: String?) {
                isSpeaking.value = false
                if (isHandsfreeMode.value) {
                    startListening()
                }
            }

            override fun onError(utteranceId: String?) {
                isSpeaking.value = false
            }
        })
    }

    fun startListening() {
        if (isSpeaking.value) {
            stopSpeaking()
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, activeLanguage.value)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, activeLanguage.value)
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }

        speechRecognizer?.startListening(intent)
        isListening.value = true
    }

    fun stopListening() {
        speechRecognizer?.stopListening()
        isListening.value = false
        currentRmsDb.value = 0f
    }

    fun speak(text: String, utteranceId: String = "ai_response") {
        if (text.isBlank()) return
        stopListening()
        val locale = if (activeLanguage.value.startsWith("bn")) Locale("bn", "BD") else Locale.US
        textToSpeech?.language = locale
        textToSpeech?.setSpeechRate(speechSpeed.value)
        textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stopSpeaking() {
        textToSpeech?.stop()
        isSpeaking.value = false
    }

    fun toggleLanguage(lang: String) {
        activeLanguage.value = lang
    }

    fun destroy() {
        speechRecognizer?.destroy()
        textToSpeech?.shutdown()
    }

    // RecognitionListener Callbacks
    override fun onReadyForSpeech(params: Bundle?) {
        isListening.value = true
    }

    override fun onBeginningOfSpeech() {}

    override fun onRmsChanged(rmsdB: Float) {
        currentRmsDb.value = rmsdB.coerceIn(0f, 12f)
    }

    override fun onBufferReceived(buffer: ByteArray?) {}

    override fun onEndOfSpeech() {
        isListening.value = false
    }

    override fun onError(error: Int) {
        isListening.value = false
        currentRmsDb.value = 0f
    }

    override fun onResults(results: Bundle?) {
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (!matches.isNullOrEmpty()) {
            val text = matches[0]
            recognizedText.value = text
            onSpeechFinalResult?.invoke(text)
        }
        isListening.value = false
    }

    override fun onPartialResults(partialResults: Bundle?) {
        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (!matches.isNullOrEmpty()) {
            recognizedText.value = matches[0]
        }
    }

    override fun onEvent(eventType: Int, params: Bundle?) {}
}
