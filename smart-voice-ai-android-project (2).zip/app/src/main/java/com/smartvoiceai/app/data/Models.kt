package com.smartvoiceai.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName

@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val role: String, // "user" or "assistant"
    val content: String,
    val voiceTranscript: Boolean = false,
    val language: String = "bn",
    val timestamp: Long = System.currentTimeMillis()
)

data class ProjectItem(
    @SerializedName("id") val id: String,
    @SerializedName("name") val name: String,
    @SerializedName("description") val description: String,
    @SerializedName("language") val language: String,
    @SerializedName("fileCount") val fileCount: Int,
    @SerializedName("createdAt") val createdAt: Long
)

data class ProjectFileItem(
    @SerializedName("name") val name: String,
    @SerializedName("path") val path: String,
    @SerializedName("language") val language: String,
    @SerializedName("content") val content: String,
    @SerializedName("lastModified") val lastModified: Long
)

data class ProjectDetails(
    @SerializedName("id") val id: String,
    @SerializedName("name") val name: String,
    @SerializedName("description") val description: String,
    @SerializedName("language") val language: String,
    @SerializedName("files") val files: List<ProjectFileItem>
)

data class TaskStep(
    @SerializedName("id") val id: String,
    @SerializedName("title") val title: String,
    @SerializedName("description") val description: String,
    @SerializedName("status") val status: String, // "pending", "in_progress", "completed", "failed"
    @SerializedName("tool") val tool: String? = null,
    @SerializedName("diff") val diff: String? = null
)

data class VoiceProcessRequest(
    @SerializedName("prompt") val prompt: String,
    @SerializedName("projectId") val projectId: String,
    @SerializedName("language") val language: String = "bn"
)

data class VoiceProcessResponse(
    @SerializedName("taskId") val taskId: String,
    @SerializedName("voiceResponse") val voiceResponse: String,
    @SerializedName("banglaExplanation") val banglaExplanation: String?,
    @SerializedName("summary") val summary: String,
    @SerializedName("verified") val verified: Boolean,
    @SerializedName("plan") val plan: TaskPlanResponse?
)

data class TaskPlanResponse(
    @SerializedName("id") val id: String,
    @SerializedName("title") val title: String,
    @SerializedName("goal") val goal: String,
    @SerializedName("status") val status: String,
    @SerializedName("steps") val steps: List<TaskStep>,
    @SerializedName("verified") val verified: Boolean,
    @SerializedName("testOutput") val testOutput: String?
)

data class SandboxExecuteResponse(
    @SerializedName("status") val status: String,
    @SerializedName("exitCode") val exitCode: Int,
    @SerializedName("verified") val verified: Boolean,
    @SerializedName("executionTimeMs") val executionTimeMs: Long,
    @SerializedName("output") val output: String,
    @SerializedName("target") val target: String,
    @SerializedName("language") val language: String
)
