package com.smartvoiceai.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.smartvoiceai.app.ui.screens.*
import com.smartvoiceai.app.voice.VoiceInteractionManager

class MainActivity : ComponentActivity() {

    private lateinit var voiceManager: VoiceInteractionManager
    private var hasMicPermission by mutableStateOf(false)

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasMicPermission = isGranted
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        voiceManager = VoiceInteractionManager(this)

        checkAndRequestAudioPermission()

        setContent {
            SmartVoiceAiAppTheme {
                MainAppNavigation(
                    voiceManager = voiceManager,
                    hasMicPermission = hasMicPermission,
                    onRequestPermission = { checkAndRequestAudioPermission() }
                )
            }
        }
    }

    private fun checkAndRequestAudioPermission() {
        when {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED -> {
                hasMicPermission = true
            }
            else -> {
                requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceManager.destroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppNavigation(
    voiceManager: VoiceInteractionManager,
    hasMicPermission: Boolean,
    onRequestPermission: () -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("Voice AI", "Workspace", "Plan & Tasks", "Sandbox Logs", "Settings")

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row {
                        Text("Smart Voice AI", style = MaterialTheme.typography.titleMedium)
                    }
                },
                actions = {
                    val activeLang by voiceManager.activeLanguage.collectAsState()
                    FilterChip(
                        selected = activeLang == "bn-BD",
                        onClick = {
                            voiceManager.toggleLanguage(if (activeLang == "bn-BD") "en-US" else "bn-BD")
                        },
                        label = { Text(if (activeLang == "bn-BD") "বাংলা (bn)" else "English (en)") }
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF111827),
                    titleContentColor = Color.White
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF0F172A),
                contentColor = Color.White
            ) {
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Mic, contentDescription = "Voice") },
                    label = { Text("Voice") },
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Code, contentDescription = "Workspace") },
                    label = { Text("Code") },
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.ListAlt, contentDescription = "Tasks") },
                    label = { Text("Plan") },
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Terminal, contentDescription = "Sandbox") },
                    label = { Text("Sandbox") },
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                    label = { Text("Settings") },
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .background(Color(0xFF0B0F19))
        ) {
            when (selectedTab) {
                0 -> HomeScreen(
                    voiceManager = voiceManager,
                    hasMicPermission = hasMicPermission,
                    onRequestPermission = onRequestPermission,
                    onNavigateToTasks = { selectedTab = 2 }
                )
                1 -> CodingWorkspaceScreen()
                2 -> TaskProgressScreen()
                3 -> TestLogsScreen()
                4 -> SettingsScreen(voiceManager = voiceManager)
            }
        }
    }
}

@Composable
fun SmartVoiceAiAppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF3B82F6),
            background = Color(0xFF0B0F19),
            surface = Color(0xFF111827),
            onPrimary = Color.White,
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}
