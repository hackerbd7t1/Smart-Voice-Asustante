package com.smartvoiceai.app.network

import com.smartvoiceai.app.data.*
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*
import java.util.concurrent.TimeUnit

interface ApiService {
    @GET("api/health")
    suspend fun checkHealth(): Response<Map<String, Any>>

    @GET("api/projects")
    suspend fun getProjects(): Response<List<ProjectItem>>

    @GET("api/projects/{id}")
    suspend fun getProjectDetails(@Path("id") id: String): Response<ProjectDetails>

    @POST("api/projects/{id}/files")
    suspend fun saveFile(
        @Path("id") id: String,
        @Body body: Map<String, String>
    ): Response<Map<String, Any>>

    @POST("api/projects/{id}/execute")
    suspend fun executeSandbox(
        @Path("id") id: String,
        @Body body: Map<String, String>
    ): Response<SandboxExecuteResponse>

    @POST("api/voice/process")
    suspend fun processVoiceRequest(
        @Body request: VoiceProcessRequest
    ): Response<VoiceProcessResponse>
}

object NetworkClient {
    private var baseUrl: String = "http://10.0.2.2:3000/" // Android Emulator default host mapping

    fun setBaseUrl(url: String) {
        baseUrl = if (url.endsWith("/")) url else "$url/"
        retrofitInstance = null
    }

    fun getBaseUrl(): String = baseUrl

    private var retrofitInstance: Retrofit? = null

    val apiService: ApiService
        get() {
            if (retrofitInstance == null) {
                val logging = HttpLoggingInterceptor().apply {
                    level = HttpLoggingInterceptor.Level.BODY
                }
                val okHttpClient = OkHttpClient.Builder()
                    .addInterceptor(logging)
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(30, TimeUnit.SECONDS)
                    .writeTimeout(30, TimeUnit.SECONDS)
                    .build()

                retrofitInstance = Retrofit.Builder()
                    .baseUrl(baseUrl)
                    .client(okHttpClient)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
            }
            return retrofitInstance!!.create(ApiService::class.java)
        }
}
