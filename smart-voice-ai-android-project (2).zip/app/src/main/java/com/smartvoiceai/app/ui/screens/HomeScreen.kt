package com.smartvoiceai.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smartvoiceai.app.data.VoiceProcessRequest
import com.smartvoiceai.app.network.NetworkClient
import com.smartvoiceai.app.voice.VoiceInteractionManager
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    voiceManager: VoiceInteractionManager,
    hasMicPermission: Boolean,
    onRequestPermission: () -> Unit,
    onNavigateToTasks: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val isListening by voiceManager.isListening.collectAsState()
    val isSpeaking by voiceManager.isSpeaking.collectAsState()
    val rmsDb by voiceManager.currentRmsDb.collectAsState()
    val activeLang by voiceManager.activeLanguage.collectAsState()
    val handsfree by voiceManager.isHandsfreeMode.collectAsState()

    var statusText by remember { mutableStateOf("Tap the microphone or speak in Bangla/English") }
    var lastAiResponse by remember { mutableStateOf("") }
    var isProcessing by remember { mutableStateOf(false) }
    var inputText by remember { mutableStateOf("") }

    // Pulsing circle animation during active listening or speech
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isListening) 1.25f else 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    fun sendToBackend(query: String) {
        if (query.isBlank()) return
        isProcessing = true
        statusText = if (activeLang == "bn-BD") "প্ল্যান তৈরি এবং স্যান্ডবক্স টেস্ট চলছে..." else "Planning & running sandbox tests..."
        coroutineScope.launch {
            try {
                val response = NetworkClient.apiService.processVoiceRequest(
                    VoiceProcessRequest(
                        prompt = query,
                        projectId = "proj-php-auth",
                        language = if (activeLang == "bn-BD") "bn" else "en"
                    )
                )
                if (response.isSuccessful && response.body() != null) {
                    val body = response.body()!!
                    lastAiResponse = body.voiceResponse
                    statusText = body.summary
                    voiceManager.speak(body.voiceResponse)
                } else {
                    statusText = "Error communicating with backend"
                }
            } catch (e: Exception) {
                statusText = "Backend error: ${e.localizedMessage}"
            } finally {
                isProcessing = false
            }
        }
    }

    LaunchedEffect(Unit) {
        voiceManager.onSpeechFinalResult = { text ->
            if (text.isNotBlank()) {
                sendToBackend(text)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Status & Language Header Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (isListening) "LISTENING..." else if (isProcessing) "ANALYZING..." else "ASSISTANT READY",
                        color = if (isListening) Color(0xFF10B981) else Color(0xFF94A3B8),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (activeLang == "bn-BD") "বাংলা (bn-BD) • সক্রিয়" else "English (en-US) • Active",
                        color = Color.White,
                        fontSize = 14.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Hands-Free", color = Color(0xFF94A3B8), fontSize = 12.sp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Switch(
                        checked = handsfree,
                        onCheckedChange = { voiceManager.isHandsfreeMode.value = it }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Center Voice Hero Orb
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(190.dp)
                .scale(if (isListening) pulseScale else 1f)
        ) {
            // Ripple background gradient
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                if (isListening) Color(0x663B82F6) else Color(0x3310B981),
                                Color.Transparent
                            )
                        ),
                        shape = CircleShape
                    )
            )

            FloatingActionButton(
                onClick = {
                    if (!hasMicPermission) {
                        onRequestPermission()
                    } else if (isListening) {
                        voiceManager.stopListening()
                    } else {
                        voiceManager.startListening()
                    }
                },
                modifier = Modifier.size(96.dp),
                shape = CircleShape,
                containerColor = if (isListening) Color(0xFFEF4444) else Color(0xFF2563EB),
                contentColor = Color.White
            ) {
                Icon(
                    imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = "Microphone",
                    modifier = Modifier.size(42.dp)
                )
            }
        }

        // Live Audio decibel meter bar
        if (isListening) {
            Text("Voice Signal: ${(rmsDb * 8).toInt()} dB", color = Color(0xFF60A5FA), fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Natural Voice Assistant Response Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("AGENT RESPONSE", color = Color(0xFF38BDF8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    if (isSpeaking) {
                        IconButton(onClick = { voiceManager.stopSpeaking() }) {
                            Icon(Icons.Default.Stop, contentDescription = "Stop", tint = Color(0xFFEF4444))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = if (lastAiResponse.isNotEmpty()) lastAiResponse else statusText,
                    color = Color.White,
                    fontSize = 14.sp
                )

                if (lastAiResponse.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = onNavigateToTasks,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("View Verified Plan & Diffs")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // Suggested Voice Prompts
        Text("Quick Prompts (বাংলা / English):", color = Color(0xFF94A3B8), fontSize = 12.sp)
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AssistChip(
                onClick = { sendToBackend("একটি নিরাপদ PHP লগইন সিস্টেম বানিয়ে দাও") },
                label = { Text("PHP লগইন সিস্টেম", fontSize = 12.sp) },
                modifier = Modifier.weight(1f)
            )
            AssistChip(
                onClick = { sendToBackend("Run sandbox unit tests for authentication") },
                label = { Text("Run Sandbox Tests", fontSize = 12.sp) },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Text Fallback Input Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = { Text("Type voice instructions...") },
                modifier = Modifier.weight(1f),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFF1E293B),
                    unfocusedContainerColor = Color(0xFF1E293B),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = {
                    sendToBackend(inputText)
                    inputText = ""
                },
                modifier = Modifier
                    .background(Color(0xFF2563EB), CircleShape)
                    .size(48.dp)
            ) {
                Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White)
            }
        }
    }
}
