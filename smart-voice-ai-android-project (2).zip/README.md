# Smart Voice AI — Native Android App & Backend Architecture

**Smart Voice AI** is a native Android personal AI assistant and coding agent built with **Kotlin** and **Jetpack Compose**, integrated with a secure, sandboxed execution backend.

---

## 🌟 Key Architecture & Highlights

1. **Native Android Client (`/android-project`)**:
   - **Modern Jetpack Compose UI & Material 3** with dark/light dynamic theming.
   - **Bilingual Voice Engine**: SpeechRecognizer supporting **Bangla (`bn-BD`)** and **English (`en-US`)**, with hands-free conversation loop, decibel wave visualizer, and interruptible Text-to-Speech.
   - **Coding Workspace Screen**: Project file explorer, code preview, and live test runner trigger.
   - **Plan-Execute-Verify Engine**: Multi-step task tracking with verified badges before claiming completion.
   - **Diff Review & Confirmation Gate**: Protects against accidental file overwrites or destructive actions.
   - **Room Database**: Local chat history and project metadata persistence without storing sensitive API keys on device.

2. **Secure Isolated Backend (`/server.ts`)**:
   - **Official `@google/genai` TypeScript SDK**: Uses `gemini-3.8-flash` for reasoning/tool calling and `gemini-3.8-flash-lite-tts` for natural conversational audio.
   - **Isolated Sandbox Execution**: Micro-sandbox running JavaScript and PHP test suites with strict CPU timeouts (3000ms), memory limits, and no host process access.
   - **Plan-Execute-Verify Workflow**: Formulates a plan, modifies code, tests in sandbox, and returns verified test reports with natural Bangla explanations.
   - **Project ZIP Exporter**: Allows downloading complete source trees directly.

---

## 🚀 How to Build & Run the Android App

### Prerequisites
- **Android Studio Iguana / Jellyfish or Ladybug+**
- **JDK 17 or JDK 21**
- **Android SDK 35 (API 35)**

### Steps to Build
1. Open Android Studio and select **Open**, then choose the `android-project` folder.
2. Wait for Gradle sync to complete.
3. Build the APK via terminal:
   ```bash
   ./gradlew assembleDebug
   ```
   Or in Android Studio: `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. The generated APK will be at:
   ```
   app/build/outputs/apk/debug/app-debug.apk
   ```
5. Install on connected phone or emulator:
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```

### Connecting to Backend
- **Android Emulator**: In app Settings, use `http://10.0.2.2:3000` (points to host machine).
- **Physical Device**: Connect to same Wi-Fi and use `http://<YOUR_PC_LOCAL_IP>:3000` or your Cloud Run URL.

---

## 🛡️ Security Guarantees
- **No API Keys in APK**: `GEMINI_API_KEY` is maintained exclusively on the server.
- **Plan-Execute-Verify**: The agent never claims success without exit code 0 verification in sandbox.
- **Path Traversal Protection**: Relative paths with `..` are sanitized and strictly locked inside the project workspace directory.
